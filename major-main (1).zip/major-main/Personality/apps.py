from django.apps import AppConfig


class PersonalityConfig(AppConfig):
    name = 'Personality'
